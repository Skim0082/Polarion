/*
 * Copyright (C) 2004-2014 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2014 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.alm.server.api.model.rp.widget;

import org.jetbrains.annotations.NotNull;

import com.polarion.alm.shared.api.model.rp.parameter.DataSetParameter;
import com.polarion.alm.shared.api.model.rp.parameter.MultiParameter;
import com.polarion.alm.shared.api.model.rp.parameter.StringParameter;
import com.polarion.alm.shared.api.model.rp.widget.RichPageWidgetRenderingContext;
import com.polarion.alm.shared.api.utils.charts.PieChartBuilder;
import com.polarion.alm.shared.api.utils.charts.PieSerieDataObject;
import com.polarion.alm.shared.api.utils.collections.ImmutableStrictList;
import com.polarion.alm.shared.util.ObjectUtils;
import com.polarion.alm.shared.util.StringUtils;

public class MultiDataSetPieChartWidgetRenderer extends AbstractPieChartWidgetRenderer {

    @NotNull
    private final ImmutableStrictList<DataSetParameter> sectors;

    public MultiDataSetPieChartWidgetRenderer(@NotNull RichPageWidgetRenderingContext context) {
        super(context);

        MultiParameter<DataSetParameter> sectorsParameter = context.parameter(MultiDataSetPieChartWidget.sectors);
        sectors = sectorsParameter.get();
    }

    @Override
    protected void buildChart(@NotNull PieChartBuilder pieBuilder) {
        int untitledSectorIndex = 1;

        for (DataSetParameter dataSetParameter : sectors) {
            int value = dataSetParameter.getFor().revision(null).size();

            if (value != 0 || showZeroValues) {
                final StringParameter sectorNameParameter = dataSetParameter.get(MultiDataSetPieChartWidget.sectorName);
                final StringParameter sectorColorParameter = dataSetParameter.get(MultiDataSetPieChartWidget.sectorColor);

                String sectorName = sectorNameParameter.value();
                if (StringUtils.isEmptyTrimmed(sectorName)) {
                    sectorName = localization().getString("richpages.widget.multiDataSetPieChart.defaultSectorName", String.valueOf(untitledSectorIndex)); //$NON-NLS-1$
                    untitledSectorIndex++;
                }

                String sectorColor = sectorColorParameter.value();

                PieSerieDataObject dataObject = pieBuilder.addValue(ObjectUtils.notNull(sectorName), value);
                if (!StringUtils.isEmptyTrimmed(sectorColor)) {
                    dataObject.color(sectorColor);
                }
            }
        }
    }

}
